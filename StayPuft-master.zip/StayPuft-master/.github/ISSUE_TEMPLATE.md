**Please check the [FAQ](https://github.com/dlecina/StayPuft#faq) before creating an issue.**

If you're filing a bug 🐛, please include the following information:

### Screenshot

![]()

### Steps to Reproduce
 
 1. This is the first step
 2. This may be the post content used to cause an issue...

### Technical details

* StayPuft Version:
* Ghost Version:
* Browser Version:
* OS Version:
